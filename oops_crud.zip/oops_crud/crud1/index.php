<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration form</title>
    <style>
        h1{
            color: blue;
            font-size: xx-large;
        }
        form{
            color: red;
            font-size: x-large;
        }
        input{
            font-size: x-large;
        }
        table{
            font-size: x-large;
            width: 100%;
        }
        body{
            background-color: yellow;
        }
    </style>
</head>
<body>
    <fieldset style="width: 30%; height: 400px;">
        <legend style="font-size:xx-large;">Form.....</legend>
    <form action="code.php" method="post">
        Name :
        <input type="text" name="name" ><br><br>
        College :
        <input type="text" name="college" ><br><br>
        Email :
        <input type="email" name="email" ><br><br>
        Mobile No :
        <input type="number" name="mobile"><br><br>
       <input type="submit" value="Submit" ><br><br><br><br>
       
    </form>
    </fieldset>
    <table border="2" style="background-color:aqua;">
        <tr>
            <td>S.No</td>
            <td>Name</td>
            <td>College</td>
            <td>Email</td>
            <td>Mobile</td>
            <td>Update</td>
            <td>Delete</td>
        </tr>
        <tbody>
            <?php
            include('function.php');
            $a=1;
            $output=$obj->read();
            ?>
            <?php
                while($row=mysqli_fetch_array($output))
                {

                ?>
            <tr>
                
                <td><?php echo $a; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['college']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['mobile']; ?></td>
                <td><a href="update.php?id=<?php echo $row['id'] ?>">Update</a></td>
                <td><a href="delete.php?id=<?php echo $row['id'] ?>" >Delete</a></td>


                
            </tr>
            <?php
                $a++;

                }
                ?>
        </tbody>
    </table>
    
</body>
</html>