<?php
class db
{
    public $server;
    public $user;
    public $pass;
    public $db;
    public $eon;

    function __construct($server,$user,$pass,$db)
    {
        $this->server=$server;
        $this->user=$user;
        $this->pass=$pass;
        $this->db=$db;
    }
    public function DB_CON()
    {
          $con=mysqli_connect($this->server,$this->user,$this->pass,$this->db);
          return $con;
    }
    public function insert($name,$college,$email,$mobile)
    {
        $query="insert into tbl_register(name,college,email,mobile) values('$name','$college','$email','$mobile')";
        $res=mysqli_query($this->DB_CON(),$query);
        return $res;
    }
    public function read()
    {
        if(isset($_GET['id']))
        {
            $id=$_GET['id'];
            $query="select * from tbl_register where id='$id'";
        }
        else
        {
            $query="select * from tbl_register";
        }
        $result=mysqli_query($this->DB_CON(),$query);
        return $result;
    }

    public function update($name,$college,$email,$mobile,$id)
    {
        $query="update tbl_register set name='$name', college='$college' ,email='$email', mobile='$mobile' where id='$id'";
        $res1=mysqli_query($this->DB_CON(),$query);
        return $res1;
    }
    public function delete($id)
    {
        $query="delete from tbl_register where id='$id'";
        $res2=mysqli_query($this->DB_CON(),$query);
        return $res2;
    }
    
}
$obj=new DB('localhost','root','','crud1');
    $m=$obj->DB_CON();
    
?>