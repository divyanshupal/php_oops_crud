<?php
include('function.php');
$name=$_POST['name'];
$college=$_POST['college'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$res=$obj->insert($name,$college,$email,$mobile);
if($res)
{
    echo "inserted success";

}
else
{
    echo "Not Inserted";
}
?>